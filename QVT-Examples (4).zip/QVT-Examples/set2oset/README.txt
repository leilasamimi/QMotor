set2oset is a bidirectional transformation working in both modes.
set2osetforward works only in forward direction and enforcing mode.
oset2set works only in backward direction, but in both modes.
In addition, it works in forward direction in checking mode.