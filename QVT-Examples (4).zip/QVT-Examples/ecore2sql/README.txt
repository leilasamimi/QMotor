This folder contains three version of bidirectional transformations between Eore models and relational schemas:

- qvt1: Transformation with annotations
- qvt2: Transformation without annotations; multiplicities of references may not be reconstructed
- qv3: Recursive descent version, exploiting nested relations and where clauses. The behavior is ill-defined.
  In the mediniQVT debugger, the call Class2Table in the where clause of Package2Schema is processed before the
  target domain has been instantiated completely (in particular, before the object table is created). Normal execution
  delivers an incomplete target model (where almost all structural features are not transformed).
  
Since the Ecore meta model is one of the candidate models in qvt1 and qvt2 (required for the backward transformation
of data types), the transformations generate run time errors (failed PUT operation; it seems that mediniQVT attempts
to write the Ecore metamodel), but generate the expected target models.

The transformations have been developed and tested with medini QVT. To make them conformant to the QVT standard,
including Annex B, the relations have to be modified with respect to the distribution of expressions over when
clauses, where clauses, and domain conditions.

medini QVT matches the source domain before evaluating the when clause, and does not support domain conditions. 
For standard compliance, some expressions in when clauses have to be moved to domain conditions and where clauses.