Author and Copyright: Bernhard Westfechtel, University of Bayreuth, bernhard.westfechtel@uni-bayreuth.de

This project contains several examples of bidirectional QVT transformations. All transformations
were developed with medini QVT 1.7 under Eclipse Indigo.

The transformation cases are described in the following paper:

Bernhard Westfechtel: Case Studies for Bidirectional Transformations in QVT Relations,
submitted to Software and Systems Modeling 

Examples:
- pn2pnw: Unweighted to weighted Petri nets
- pdb1pdb2: Migration between different versions of person databases
- bag12bag2: Migration of a bag
- set2oset: Conversion between sets and ordered sets
- gantt2cpm: Conversion between Gantt diagrams and CPM networks
- ecore2sql: Mapping from Ecore models to relational schemas
- ast2dag: Folding an AST into a dag and vice versa

For each example, the following resources are included:
- Metamodels
- QVT script
- Sample source and target models (as XMI instances; use the reflective Ecore model editor
  for inspection)
- Trace model and trace instance

All metamodels need to be made available to mediniQVT via Window/Preferences/QVT metamodels.

To run a transformation, please create a run configuration. In the dialog, activate "Apply"
after selection of the QVT script. Select a line in the region for the models to select
a source/target model for the transformation. Check the box "Delete target/trace on launch".